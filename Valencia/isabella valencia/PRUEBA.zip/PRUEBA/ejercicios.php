<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CALULAR ÁREA DE UN TRIÁNGULO</title>
</head>
<body>
<center>
<img src= "https://www.tutorela.es/_ipx/f_png,s_500x305/https://cdn.tutorela.es/images/A1-_Como_hallar_el_area_de_un_triangulo.width-500.png" width="260px" height="260px"/>
    <h1>ÁREA DE UN TRIÁNGULO</h1>

    <?php 
   
    $base = 5;
    $altura= 8;
    
    $area = ($base * $altura) /2; 


    echo "<p> La base del triángulo es: " . $base . "</p>";
    echo "<p> La altura del triángulo es: " . $altura . "</p>";
    echo "<p> El área del triángulo es: " . $area . "</p>";
    ?>
</body>
</html>