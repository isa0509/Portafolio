<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOLA MUNDO</title>
</head>
<body>
<center>
<img src= "https://www.jovenesprogramadores.cl/wp-content/uploads/2020/07/php.png" width="90px" height="90px"/>
    <?php
    echo "HOLA MUNDO"
    ?> 
</center>
</body>
</html> 